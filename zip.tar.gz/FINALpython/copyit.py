import sys
import os
from distutils.dir_util import copy_tree
copy_tree("/home/ksimms5/FINALinstruction", "/home/ksimms5/FINALc/copies");
copy_tree("/home/ksimms5/FINALinstruction", "/home/ksimms5/FINALpython/copies");
