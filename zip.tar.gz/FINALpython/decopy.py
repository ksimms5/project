import time, os, sys
def main():
        inputfile = "/home/ksimms5/FINALpython/encryption/"
        outputfile = "/home/ksimms5/FINALpython/copies/FINALinstruction"
        key = 150
        while () {
        c - key
        key = key + 1 < 0 ? (key +1) * 256 :255;
        fileOBJ = open(inputfile)
        info = fileOBJ.read()
        fileOBJ.close()
        output=open(outputfile,"w")
        output.write(translated)
        output.close()

if _name_= '_main_':
main()

~                                                                                                
~                                                                                                
~                                                                                                
~                 
