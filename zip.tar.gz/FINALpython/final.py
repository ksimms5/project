import os
import shutil
import sys
os.mkdir('FINALpython')
os.mkdir('FINALpython/copies')
os.mkdir('FINALpython/encrypted')
os.mkdir('FINALpython/decrypted')
shutil.copyfile('/home/ksimms5/final.py', '/home/ksimms5/FINALpython/final.py')
